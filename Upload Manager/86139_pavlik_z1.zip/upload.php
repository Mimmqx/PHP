<?php
    $target_dir = "/home/xpavlikm3/public_html/cviko1/uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = pathinfo($target_file,PATHINFO_EXTENSION);
$array = explode('.', basename($_FILES["fileToUpload"]["name"]));
$extension = end($array);
$name_file = $target_file;
$name_ext = pathinfo($name_file,PATHINFO_EXTENSION);
$name_name = pathinfo($name_file,PATHINFO_FILENAME);
//echo $name_file.date("mjYHis").".".$name_ext;
$name_file = $name_file.date("mjYHis").".".$name_ext;
//$name_file =
  if(isset($_POST["submit"])) {

    if($_POST["nazovsuboru"]!=""){
        rename(basename($_FILES["fileToUpload"]["name"]),$target_dir.$_POST["nazovsuboru"]."." .$extension);
        $name_file = $target_dir.$_POST['nazovsuboru']."." .$extension;
        //echo $target_dir.$_POST["nazovsuboru"]."." .$extension;
        $name_file = $target_dir.$_POST["nazovsuboru"]."_" ;
        $name_file = $name_file.date("mjYHis").".".$name_ext;
    }
        $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
        if($check !== false) {
            echo "File is an image - " . $check["mime"] . ".";
            $uploadOk = 0;
        } else {
            echo "File is not an image.";
            $uploadOk = 1;
        }

    }
    // Check if file already exists
    //if (file_exists($target_file)) {
      //  echo "Sorry, file already exists.";
        //$uploadOk = 0;
    //}
    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }
    // Allow certain file formats
    if($imageFileType != "txt" ) {
        echo "Sorry, only txt files are allowed.";
        $uploadOk = 0;
    }
    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    // if everything is ok, try to upload file
    } else {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"],  $name_file)) {
            echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
    ?>