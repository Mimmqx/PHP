
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <script src="sort.js" async></script>
    <title>Document</title>
</head>
<body>
<div class="content">
    <form action="upload.php" method="post" enctype="multipart/form-data">
        Select file to upload:
        <br>
        <input type="file" name="fileToUpload" id="fileToUpload">
        <br>
        <input type="text" name= "nazovsuboru" id= "nazovsuboru" placeholder="Zadaj nazov suboru">
        <br>
        <input type="submit" value="Nahraj" name="submit">
    </form>

    <?php
        include("table.php");
    ?>

</div>
</body>
</html>