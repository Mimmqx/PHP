<?php

echo "<table  class=\"table table-hover table-bordered sortable\" id='file-table'>";
echo "<thead> <tr><th>Name</th> <th>Size in bytes</th> <th>Date</th> </tr></thead> <tbody>";

if ($_GET["subf"]!=NULL){
    $path = $_GET["subf"];
}
else {
    $path = getcwd();
}
//echo $path;
getpath($path);

function getpath($path){
    $dir_handle = opendir($path) or die("nope");
    $parf = dirname($path);
    while($file = readdir($dir_handle))
    {
        if($file != "."){
            $dirpath = $path.'/'.$file;

            if(strpos($dirpath, 'zd1') !== false){
                header('Location: index.php');
            }
            else if(is_dir($dirpath))
            {
                echo "<tr><td><a href='index.php?subf=".$path."/".$file."'>". $file ." </a></td><td>". filesize($file)."</td><td> " . date ("F d Y H:i:s",
                        filemtime($file)) . "<br>";
            }
            elseif ($file == ".."){
                echo "<tr><td><a href='index.php?subf=".$parf."'>". $file ."</a></td><td></td><td><br>";
            }
            else{
                $files = "./uploads/";
                $filepath = $files."/".$file;

                if (filesize($file) == ""){
                    echo "<tr><td>" . $file ."</td><td>". filesize($filepath)."</td><td> " . date("F d Y H:i:s", filemtime($filepath)) . "<br>";
                }
                else{
                    echo "<tr><td>" . $file ."</td><td>". filesize($file)."</td><td> " . date("F d Y H:i:s", filemtime($file)) . "<br>";
                }
            }
        }
    }
    closedir($dir_handle);
    echo "</tbody></table>";
}
?>