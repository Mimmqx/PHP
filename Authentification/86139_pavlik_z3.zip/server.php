<?php
session_start();

// initializing variables
$username = "";
$email    = "";
$errors = array();

// connect to the database
$db = mysqli_connect('localhost', 'xpavlikm3', 'Feistujebem123', 'zadanie3');

// REGISTER USER
if (isset($_POST['reg_user'])) {
    echo 'good';
    // receive all input values from the form
    $name = mysqli_real_escape_string($db, $_POST['name']);
    $surname = mysqli_real_escape_string($db, $_POST['surname']);
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $email = mysqli_real_escape_string($db, $_POST['email']);
    $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
    $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

    echo $username;
    echo $email;
    // form validation: ensure that the form is correctly filled ...
    // by adding (array_push()) corresponding error unto $errors array
    if (empty($username)) { array_push($errors, "Username is required"); }
    if (empty($email)) { array_push($errors, "Email is required"); }
    if (empty($password_1)) { array_push($errors, "Password is required"); }
    if ($password_1 != $password_2) {
        array_push($errors, "The two passwords do not match");
    }

    // first check the database to make sure
    // a user does not already exist with the same username and/or email
    $user_check_query = "SELECT * FROM uzivatelia WHERE username='$username' OR email='$email' LIMIT 1";
    $result = mysqli_query($db, $user_check_query);
    $user = mysqli_fetch_assoc($result);

    if ($user) { // if user exists
        if ($user['username'] === $username) {
            array_push($errors, "Username already exists");
        }

        if ($user['email'] === $email) {
            array_push($errors, "email already exists");
        }
    }

    // Finally, register user if there are no errors in the form
    if (count($errors) == 0) {
        $password = md5($password_1);//encrypt the password before saving in the database

        $query = "INSERT INTO uzivatelia (name,surname,email, login, password) 
  			  VALUES('$name','$surname','$email', '$username', '$password')";
        mysqli_query($db, $query);
        $_SESSION['username'] = $username;
        $_SESSION['success'] = "You are now logged in";
        header('location: login.php');
        //echo 'good';
    }
}

if (isset($_POST['login_user'])) {
    $username = mysqli_real_escape_string($db, $_POST['username']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    if (empty($username)) {
        array_push($errors, "Username is required");
    }
    if (empty($password)) {
        array_push($errors, "Password is required");
    }

    if (count($errors) == 0) {
        $password = md5($password);
        $query = "SELECT * FROM uzivatelia WHERE login='$username' AND password='$password'";
        $results = mysqli_query($db, $query);
        if (mysqli_num_rows($results) == 1) {
            $row = $results->fetch_assoc();
            $id_person = $row["id_person"];
            $_SESSION['id_person'] = $row["id_person"];
            $_SESSION['username'] = $username;
            $_SESSION['success'] = "You are now logged in";
            $date_clicked = date('Y-m-d H:i:s');
            $basic_login = "Basic";
            $ldap_login = "LDAP";
            $google_login = "Google";
            $query1 = "INSERT INTO prihlasenia (id_person,login,time,type_login) 
  			  VALUES('$id_person','$username','$date_clicked', '$basic_login')";
            mysqli_query($db, $query1);
            $query2 = "SELECT * FROM prihlasenia WHERE id_person='$id_person'";
            $query3 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$basic_login'";
            $query4 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$ldap_login'";
            $query5 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$google_login'";
            //$data=mysqli_fetch_assoc($query3);
            $result2 = mysqli_query($db, $query2);
            $result3 = mysqli_query($db, $query3);
            $result4 = mysqli_query($db, $query4);
            $result5 = mysqli_query($db, $query5);
            $vysledok2 = mysqli_fetch_assoc($result3);
            $vysledok3 = mysqli_fetch_assoc($result4);
            $vysledok4 = mysqli_fetch_assoc($result5);
            //$result2 = $conn->query($query2);
            while ($riadok = mysqli_fetch_assoc($result2)) {
                $vysledok[] = $riadok;
            }
//            while ($riadok = mysqli_fetch_assoc($result3)) {
//                $vysledok2[] = $riadok;
//            }
            $_SESSION['result'] = $vysledok;
            $_SESSION['basic'] =  $vysledok2;
            $_SESSION['ldap'] =  $vysledok3;
            $_SESSION['google'] =  $vysledok4;
            header('location: index.php');
        }else {
            array_push($errors, "Wrong username/password combination");
        }
    }
}

if (isset($_POST['AIS'])) {
        $adServer = "ldap.stuba.sk";

        $dn  = 'ou=People, DC=stuba, DC=sk';
        $username = $_POST['username'];
        $password = $_POST['password'];
        $ldaprdn  = "uid=$username, $dn";

        $ldapconn = ldap_connect($adServer);
        ldap_set_option($ldapconn, LDAP_OPT_PROTOCOL_VERSION, 3);

        $bind = ldap_bind($ldapconn, $ldaprdn, $password);
        if ($bind){

            $results=ldap_search($ldapconn,$dn,"uid=$username",array("givenname","sn","mail","cn","uisid","uid"));
            $info=ldap_get_entries($ldapconn,$results);
            $i=0;
            $aisUdaje = array("Meno"=>$info[$i]['givenname'][0],
                "Priezvisko"=>$info[$i]['sn'][0],
                "Používateľské meno"=>$info[$i]['uid'][0],
                "Id"=>$info[$i]['uisid'][0],
                "Email"=>$info[$i]['mail'][0]);

            $meno=$info[$i]['givenname'][0];
            $priezvisko=$info[$i]['sn'][0];
            $email=$info[$i]['mail'][0];
            $login=$info[$i]['uid'][0];

            echo "Success";
            //$conn->close;
            //$_SESSION['meno']=$info[$i]['uid'][0];
           // $_SESSION['email']=$info[$i]['mail'][0];
            $_SESSION['username'] = $username;
            $_SESSION['success'] = "You are now logged in";

            $date_clicked = date('Y-m-d H:i:s');
            $basic_login = "Basic";
            $ldap_login = "LDAP";
            $google_login = "Google";
            $query1 = "INSERT INTO prihlasenia (id_person,login,time,type_login) 
  			  VALUES('0','$username','$date_clicked', '$ldap_login')";
            mysqli_query($db, $query1);
            $query2 = "SELECT * FROM prihlasenia WHERE login='$username' AND type_login='$ldap_login'";
            $query3 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$basic_login'";
            $query4 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$ldap_login'";
            $query5 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$google_login'";
            $result2 = mysqli_query($db, $query2);
            $result3 = mysqli_query($db, $query3);
            $result4 = mysqli_query($db, $query4);
            $result5 = mysqli_query($db, $query5);
            $vysledok2 = mysqli_fetch_assoc($result3);
            $vysledok3 = mysqli_fetch_assoc($result4);
            $vysledok4 = mysqli_fetch_assoc($result5);
            //$vysledok = mysqli_fetch_assoc($result2);
            //$result2 = $conn->query($query2);
            while ($riadok = mysqli_fetch_assoc($result2)) {
                $vysledok[] = $riadok;
            }
            $_SESSION['result'] = $vysledok;
            $_SESSION['basic'] =  $vysledok2;
            $_SESSION['ldap'] =  $vysledok3;
            $_SESSION['google'] =  $vysledok4;
            header("Location: index.php");
        }
        else {
            echo "Chyba pripojenia na server!";
        }


}

if (isset($_POST['Google']) || isset($authUrl) || isset($_GET['logout']) || isset($_GET['code']) ||(isset($_SESSION['access_token']) && $_SESSION['access_token'])) {

    require_once ('google_login/libraries/Google/autoload.php');
//require "../config.php";
//Insert your cient ID and secret
//You can get it from : https://console.developers.google.com/
    $client_id = '840239117233-tjqstgefe7qog8olehm8cph9rcpe6rrr.apps.googleusercontent.com';
    $client_secret = 'NYteuJfKV21jnum6PIifYWNl';
    $redirect_uri = 'https://147.175.121.210.nip.io:4111/cviko3/server.php';


//incase of logout request, just unset the session var
    if (isset($_GET['logout'])) {
        unset($_SESSION['access_token']);
    }

    /************************************************
    Make an API request on behalf of a user. In
    this case we need to have a valid OAuth 2.0
    token for the user, so we need to send them
    through a login flow. To do this we need some
    information from our API console project.
     ************************************************/
    $client = new Google_Client();
    $client->setClientId($client_id);
    $client->setClientSecret($client_secret);
    $client->setRedirectUri($redirect_uri);
    $client->addScope("email");
    $client->addScope("profile");

    /************************************************
    When we create the service here, we pass the
    client to it. The client then queries the service
    for the required scopes, and uses that when
    generating the authentication URL later.
     ************************************************/
    $service = new Google_Service_Oauth2($client);

    /************************************************
    If we have a code back from the OAuth 2.0 flow,
    we need to exchange that with the authenticate()
    function. We store the resultant access token
    bundle in the session, and redirect to ourself.
     */

    if (isset($_GET['code'])) {
        $client->authenticate($_GET['code']);
        $_SESSION['access_token'] = $client->getAccessToken();
        header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
        exit;
    }

    /************************************************
    If we have an access token, we can make
    requests, else we generate an authentication URL.
     ************************************************/
    if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
        $client->setAccessToken($_SESSION['access_token']);
    } else {
        $authUrl = $client->createAuthUrl();
        echo $authUrl;
    }


//Display user info or display login url as per the info we have.
    echo '<div style="margin:20px">';
    if (isset($authUrl)){
        //show login url
        echo '<div align="center">';
        echo '<h3>Login with Google -- Demo</h3>';
        echo '<div>Please click login button to connect to Google.</div>';
        echo '<a class="login" href="' . $authUrl . '"><img src="images/google-login-button.png" /></a>';
        echo '</div>';
        header("Location: $authUrl");

    }else {

        $user = $service->userinfo->get(); //get user info
        print_r($user);
        $today=date("Y-m-d H:i:s");
        $moj_mail=$user->email;

        $basic_login = "Basic";
        $ldap_login = "LDAP";
        $google_login = "Google";
        $query5="INSERT INTO prihlasenia(id_person,login,time,type_login) VALUES ('1', '$moj_mail','$today','$google_login')";
        mysqli_query($db, $query5);

        $meno=$user->givenName;
        $priezvisko=$user->givenfamilyName;
        $celemeno=$user->name;

        $query2 = "SELECT * FROM prihlasenia WHERE login='$moj_mail' AND type_login='$google_login'";
        $query3 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$basic_login'";
        $query4 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$ldap_login'";
        $query5 = "SELECT COUNT(*) as total FROM prihlasenia WHERE type_login='$google_login'";
        $result2 = mysqli_query($db, $query2);
        $result3 = mysqli_query($db, $query3);
        $result4 = mysqli_query($db, $query4);
        $result5 = mysqli_query($db, $query5);
        $vysledok2 = mysqli_fetch_assoc($result3);
        $vysledok3 = mysqli_fetch_assoc($result4);
        $vysledok4 = mysqli_fetch_assoc($result5);
        while ($riadok = mysqli_fetch_assoc($result2)) {
            $vysledok[] = $riadok;
        }
        $_SESSION['result'] = $vysledok;
        $_SESSION['username']=$moj_mail;
        $_SESSION['basic'] =  $vysledok2;
        $_SESSION['ldap'] =  $vysledok3;
        $_SESSION['google'] =  $vysledok4;
        header("Location: index.php");
//    }

        $conn->close();

        echo '</div>';}
}