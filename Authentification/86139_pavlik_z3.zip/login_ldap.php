<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

session_start();
$ldapuid = $_POST['username'];

$basedn  = 'ou=People, DC=stuba, DC=sk';
$ds = @ldap_connect('ldap://ldap.stuba.sk', 636);
@ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);

$ldapFilter = array("uid", "uisid", "cn", "givenname","surname","mail");

$ldapSearchResult = @ldap_search($ds, $basedn, 'uid='.$ldapuid, $ldapFilter);

if ($ldapSearchResult) {
    echo 'skap';
    $result = @ldap_get_entries($ds, $ldapSearchResult);
    $uid = $result[0]['uisid'][0];
    $meno = $result[0]['cn'][0];
    @ldap_close($ds);

    $_SESSION['uid'] = $uid;
    $_SESSION['meno'] = $meno;
}
if (isset($_SESSION['uid'])) {
    header("Location: index.php");
}


//function insertPrihlasenie($meno,$priezvisko,$id,$login,$password){
//
//    require "config.php";
//
//    $conn = new mysqli($servernamedb, $usernamedb, $passworddb, $dbnamedb);
//
//    if (!$conn) {
//        die("Connection failed:".mysqli_connect_error());
//        echo "padne tu";
//    }
//
//    $today=date("Y-m-d H:i:s");
//
//    $sql="INSERT INTO login(sposob_prihl,log_uz,cas) VALUES ('ldap', '$id','$today')";
//
//    $result=$conn->query($sql);
//    if ($result===FALSE) {
//        echo "Cannot work with database";
//        //$conn->close;
//        //header("Location: index.php");
//    }
//
//    $sql2="SELECT email FROM pouzivatel WHERE email='$id'";
//    $result2=$conn->query($sql2);
//
//    $hash_pass=md5($password);
//
//    if ($result2->num_rows==0) {
//        $sql3="INSERT INTO pouzivatel(meno,priezvisko,email,login,heslo) VALUES('$meno','$priezvisko','$id','$login','$hash_pass')";
//
//
//
//        $conn->query($sql3);
//
//    }
//
//
//    $conn->close();
//}


?>