<?php
session_start();

//Google API PHP Library includes
require_once 'vendor/autoload.php';

// Set config params to acces Google API
$client_id = '840239117233-tjqstgefe7qog8olehm8cph9rcpe6rrr.apps.googleusercontent.com';
 $client_secret = 'NYteuJfKV21jnum6PIifYWNl';
 $redirect_uri = 'https://147.175.121.210.nip.io:4111/cviko3/index.php';

//Create and Request to access Google API
$client = new Google_Client();
$client->addScope('https://mail.google.com/');
$client->setApplicationName("Google OAuth Login With PHP");
$client->setClientId($client_id);
$client->setClientSecret($client_secret);
$client->setRedirectUri($redirect_uri);
$service = new Google_Service_Oauth2($client);
$objRes = new Google_Service_Oauth2($client);
//Add access token to php session after successfully authenticate
if (isset($_GET['code'])) {
    $client->authenticate($_GET['code']);
    $_SESSION['access_token'] = $client->getAccessToken();
    $user = $service->userinfo->get();
    $moj_mail=$user->email;
    $db = mysqli_connect('localhost', 'xpavlikm3', 'Feistujebem123', 'zadanie3');
    $sql="INSERT INTO prihlasenia(id_person,login,time,type_login) VALUES ('0', '$moj_mail','hghjhjh','google')";
    mysqli_query($db, $sql);
    header('Location: ' . filter_var($redirect_uri, FILTER_SANITIZE_URL));
}

//set token
if (isset($_SESSION['access_token']) && $_SESSION['access_token']) {
    $client->setAccessToken($_SESSION['access_token']);
}

//store with user data
if ($client->getAccessToken()) {
    $userData = $objRes->userinfo->get();
    if(!empty($userData)) {
        //insert data into database
    }
    $_SESSION['access_token'] = $client->getAccessToken();
} else {
    $googleAuthUrl  =  $client->createAuthUrl();
}


//$user = $service->userinfo->get();
//$moj_mail=$user->email;
//$db = mysqli_connect('localhost', 'xpavlikm3', 'Feistujebem123', 'zadanie3');
//$sql="INSERT INTO prihlasenia(id_person,login,time,type_login) VALUES ('0', '$moj_mail','hghjhjh','google')";
//$conn->query($sql);
//mysqli_query($db, $sql);
//$gpUserProfile = $google_oauthV2->userinfo->get();
//$_SESSION['google'] =  $gpUserProfile['email'];
?>

<!--if ($gClient->getAccessToken()) {-->
<!--//Get user profile data from google-->
<!--$gpUserProfile = $google_oauthV2->userinfo->get();-->
<!---->
<!--if(!empty($gpUserProfile)){-->
<!--$output = '<h1>Google </h1>';-->
<!--$output = '<h1>Google+ Profile Details </h1>';-->
<!--$output .= '<img src="'.$gpUserProfile['picture'].'" width="300" height="220">';-->
<!--$output .= '<br/>Google ID : ' . $gpUserProfile['id'];-->
<!--$output .= '<br/>Name : ' . $gpUserProfile['given_name'].' '.$gpUserProfile['family_name'];-->
<!--$output .= '<br/>Email : ' . $gpUserProfile['email'];-->
<!--$output .= '<br/>Locale : ' . $gpUserProfile['locale'];-->
<!--$email=$gpUserProfile['email'];-->
