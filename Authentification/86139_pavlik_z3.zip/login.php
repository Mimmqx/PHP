<?php include('server.php');
session_start();?>
<!DOCTYPE html>
<html>
<head>
    <title>Registration system PHP and MySQL</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <script src="https://apis.google.com/js/platform.js" async defer></script>
</head>
<body>
<div class="header">
    <h2>Login</h2>
</div>

<form method="post" action="login.php">
    <?php include('errors.php'); ?>
    <div class="input-group">
        <label>Username</label>
        <input type="text" name="username" >
    </div>
    <div class="input-group">
        <label>Password</label>
        <input type="password" name="password">
    </div>

    <div class="col text-center">
        <input type="submit"  name="login_user" value="Login">
    </div>

    <div class="col text-center">
        <input type="submit" name="AIS" value="AIS STU">
    </div>

    <div class="col text-center">
        <input type="submit" name="Google" value="Google">
    </div>

    <p>
        Not yet a member? <a href="register.php">Sign up</a>
    </p>
</form>
<?php
session_start();
echo $_SESSION['google'];
if (isset($_POST['AIS'])) {
    include "login_ldap.php";
}

?>
</body>
</html>

