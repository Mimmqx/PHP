<?php
$servernamedb = "localhost";
$usernamedb = "root";
$passworddb = "Feistujebem123";
$dbnamedb = "zadanie3";
?>