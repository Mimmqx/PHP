<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>
<div class="content">
<?php
session_start();
echo "<table border='1'>";
echo "<thead> <tr><th>Login</th><th>Time</th><th>Type</th></tr></thead> <tbody>";
foreach($_SESSION['result'] as $row) {

    echo "<td>".$row['login']. "</td>" . "<td>".$row['time']. "</td> " ."<td>". $row['type_login']. "</td>";
    echo "</tr>";
}
echo "</table>";

echo "<br>";
echo "<table border='1'>";
echo "<thead> <tr><th>Count</th><th>Type</th></tr></thead> <tbody>";
echo "<td>".$_SESSION['basic']['total']. "</td>". "<td>"."Basic". "</td> ";
echo "</tr>";
echo "<td>".$_SESSION['ldap']['total']. "</td>". "<td>"."LDAP". "</td> ";
echo "</tr>";
echo "<td>".$_SESSION['google']['total']. "</td>". "<td>"."Google". "</td> ";
echo "</table>";

?>
</div>
</body>
</html>
