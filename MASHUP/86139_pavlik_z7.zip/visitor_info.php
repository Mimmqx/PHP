<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Informácie o lokalite</title>
    <meta charset="utf-8"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
</head>
<body>
<hr>
<ul>
    <li><a href="http://147.175.121.210:8111/cviko7/index.php">Informácie o počasí vo Vašej lokalite</a></li>
    <li><a href="">Informácie o Vašej lokalite</a></li>
    <li><a href="http://147.175.121.210:8111/cviko7/statistics.php">Štatistiky</a></li>
</ul>
<hr>
<h1>Informácie o Vašej lokalite</h1>
<hr>
<?php
function getUserIP()
{
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIP();
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));


require_once "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// check connection
if ($conn->connect_error) {
    die("Connection failed : " . $conn . connect_error);
}

// GET CONTINENT
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
            }
        }
    }
    return $output;
}

//

$result = ip_info($ip, "Location");

$time_zone = getTimeZoneFromIpAddress();
// echo 'Your Time Zone is '.$time_zone;

function getTimeZoneFromIpAddress(){
    $clientsIpAddress = get_client_ip();

    $clientInformation = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$clientsIpAddress));

    $clientsLatitude = $clientInformation['geoplugin_latitude'];
    $clientsLongitude = $clientInformation['geoplugin_longitude'];
    $clientsCountryCode = $clientInformation['geoplugin_countryCode'];

    $timeZone = get_nearest_timezone($clientsLatitude, $clientsLongitude, $clientsCountryCode) ;

    return $timeZone;

}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function get_nearest_timezone($cur_lat, $cur_long, $country_code = '') {
    $timezone_ids = ($country_code) ? DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country_code)
        : DateTimeZone::listIdentifiers();

    if($timezone_ids && is_array($timezone_ids) && isset($timezone_ids[0])) {

        $time_zone = '';
        $tz_distance = 0;

        //only one identifier?
        if (count($timezone_ids) == 1) {
            $time_zone = $timezone_ids[0];
        } else {

            foreach($timezone_ids as $timezone_id) {
                $timezone = new DateTimeZone($timezone_id);
                $location = $timezone->getLocation();
                $tz_lat   = $location['latitude'];
                $tz_long  = $location['longitude'];

                $theta    = $cur_long - $tz_long;
                $distance = (sin(deg2rad($cur_lat)) * sin(deg2rad($tz_lat)))
                    + (cos(deg2rad($cur_lat)) * cos(deg2rad($tz_lat)) * cos(deg2rad($theta)));
                $distance = acos($distance);
                $distance = abs(rad2deg($distance));
                // echo '<br />'.$timezone_id.' '.$distance;

                if (!$time_zone || $tz_distance > $distance) {
                    $time_zone   = $timezone_id;
                    $tz_distance = $distance;
                }

            }
        }
        return  $time_zone;
    }
    return 'unknown';
}


date_default_timezone_set($time_zone);
$date = new DateTime();
$date->modify('-21 minutes');
$dateString = $date->format('Y-m-d H:i:s');

$sql = "INSERT INTO INFO (PAGE, IP, LOGTIME, COUNTRY, FULLCOUNTRY, CITY)
VALUES ('2','" . $ip . "','" . $dateString . "','" . $details->country . "','" . $result[country] . "','" . $details->city . "')";

$conn->query($sql);


$api_1 = 'https://ipapi.co/' . $ip . '/latlong/';

$curl_handle = curl_init();
curl_setopt($curl_handle, CURLOPT_URL, $api_1);
curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_handle, CURLOPT_USERAGENT, 'getLatLong');
$location = curl_exec($curl_handle);
curl_close($curl_handle);

$point = explode(",", $location);

echo "<script>
        $.ajax({
                    type: 'GET',
                    url: 'https://restcountries.eu/rest/v2/alpha/" . $details->country . "',
                    success: function (msg) {
                        $(\"#myDiv\").html('Hlavné mesto štátu : ' + msg.capital);
                    }
                });

</script>";

echo "Vaša IP adresa        : " . $details->ip;
echo "<br>";
echo "Zemepisná šírka       : " . $point[0];
echo "<br>";
echo "Zemepisná dĺžka       : " . $point[1];
echo "<br>";
if ($details->city == "") {
    echo "Mesto sa nedá lokalizovať alebo sa nachádzate na vidieku";
} else {
    echo "Mesto                 : " . $details->city;
}
echo "<br>";
echo "Štát                  : " . $details->country;
echo "<br>";
?>

<div id="myDiv"></div>
<hr>
</body>
</html>
