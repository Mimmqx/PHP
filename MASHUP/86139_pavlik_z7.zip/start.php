<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Informácie o počasí</title>
    <meta charset="utf-8"/>
</head>
<body>
<hr>
<button onclick="myFunction()">Entry to website</button>
<hr>


<script>
    function myFunction() {
        var response = false;
        if (confirm("Kliknutím na tlačidlo 'OK' súhlasíte, že stránka získa povolenie spracovať vašu IP adresu a GPS súradnice")) {
            response = true;
        } else {
            response = false;
        }
        if (response == true) {
            window.location.href = "http://147.175.121.210:8111/cviko7/index.php";
        }
    }
</script>
</body>

</html>

