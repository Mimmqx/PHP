<?php

$servername = "localhost";
$username = "xpavlikm3";
$password = "Feistujebem123";
$dbname = "VISITORS";

?>

