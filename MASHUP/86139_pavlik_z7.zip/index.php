<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Informácie o počasí</title>
    <meta charset="utf-8"/>
</head>
<body>
<hr>
<ul>
    <li><a href="">Informácie o počasí vo Vašej lokalite</a></li>
    <li><a href="http://147.175.121.210:8111/cviko7/visitor_info.php">Informácie o Vašej lokalite</a></li>
    <li><a href="http://147.175.121.210:8111/cviko7/statistics.php">Štatistiky</a></li>
</ul>
<hr>
<h1>Počasie vo Vašej lokalite</h1>
<hr>
<?php
function getUserIP()
{
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIP();
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));

require_once "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// check connection
if ($conn->connect_error) {
    die("Connection failed : " . $conn . connect_error);
}

// GET CONTINENT
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
                case "region":
                    $output = @$ipdat->geoplugin_regionName;
                    break;
            }
        }
    }
    return $output;
}

//

$result = ip_info($ip, "Location");


$time_zone = getTimeZoneFromIpAddress();
// echo 'Your Time Zone is '.$time_zone;

function getTimeZoneFromIpAddress()
{
    $clientsIpAddress = get_client_ip();

    $clientInformation = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip=' . $clientsIpAddress));

    $clientsLatitude = $clientInformation['geoplugin_latitude'];
    $clientsLongitude = $clientInformation['geoplugin_longitude'];
    $clientsCountryCode = $clientInformation['geoplugin_countryCode'];

    $timeZone = get_nearest_timezone($clientsLatitude, $clientsLongitude, $clientsCountryCode);

    return $timeZone;

}

function get_client_ip()
{
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if (getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if (getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if (getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if (getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if (getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function get_nearest_timezone($cur_lat, $cur_long, $country_code = '')
{
    $timezone_ids = ($country_code) ? DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country_code)
        : DateTimeZone::listIdentifiers();

    if ($timezone_ids && is_array($timezone_ids) && isset($timezone_ids[0])) {

        $time_zone = '';
        $tz_distance = 0;

        //only one identifier?
        if (count($timezone_ids) == 1) {
            $time_zone = $timezone_ids[0];
        } else {

            foreach ($timezone_ids as $timezone_id) {
                $timezone = new DateTimeZone($timezone_id);
                $location = $timezone->getLocation();
                $tz_lat = $location['latitude'];
                $tz_long = $location['longitude'];

                $theta = $cur_long - $tz_long;
                $distance = (sin(deg2rad($cur_lat)) * sin(deg2rad($tz_lat)))
                    + (cos(deg2rad($cur_lat)) * cos(deg2rad($tz_lat)) * cos(deg2rad($theta)));
                $distance = acos($distance);
                $distance = abs(rad2deg($distance));
                // echo '<br />'.$timezone_id.' '.$distance;

                if (!$time_zone || $tz_distance > $distance) {
                    $time_zone = $timezone_id;
                    $tz_distance = $distance;
                }

            }
        }
        return $time_zone;
    }
    return 'unknown';
}

echo "<br>";

date_default_timezone_set($time_zone);
$date = new DateTime();
$date->modify('-21 minutes');
$dateString = $date->format('Y-m-d H:i:s');

$sql = "INSERT INTO INFO (PAGE, IP, LOGTIME, COUNTRY, FULLCOUNTRY, CITY)
VALUES ('1','" . $ip . "','" . $dateString . "','" . $details->country . "','" . $result[country] . "','" . $details->city . "')";

$conn->query($sql);

if ($details->city != "") {
    echo "<h3>Mesto : " . $details->city . " (" . $details->country . ") </h3>";
    echo "<br>";
} else {
    echo "<h3>Mesto sa nedá lokalizovať alebo sa nachádzate na vidieku</h3>";
    echo "<br>";
}

$api_1 = 'https://ipapi.co/' . $ip . '/latlong/';

$curl_handle = curl_init();
curl_setopt($curl_handle, CURLOPT_URL, $api_1);
curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_handle, CURLOPT_USERAGENT, 'getLatLong');
$location = curl_exec($curl_handle);
curl_close($curl_handle);

$point = explode(",", $location);

$api_2 = 'http://api.openweathermap.org/data/2.5/weather?lat=' . $point[0] . '&lon=' . $point[1] . '&appid=29c9b37830cac204fb1189070d5f213b';
$curl_handle = curl_init();
curl_setopt($curl_handle, CURLOPT_URL, $api_2);
curl_setopt($curl_handle, CURLOPT_CONNECTTIMEOUT, 2);
curl_setopt($curl_handle, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($curl_handle, CURLOPT_USERAGENT, 'getWeather');
$weather = curl_exec($curl_handle);
curl_close($curl_handle);

// print all
// echo $weather;

$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator(json_decode($weather, TRUE)),
    RecursiveIteratorIterator::SELF_FIRST);

$city_id;
foreach ($jsonIterator as $key => $val) {
    if (is_array($val)) {

    } else {
        if ($key == "temp") {
            $kelvin = floatval($val);
            $celsius = $kelvin - 272.15;
            echo "&nbsp;&nbsp;&nbsp;Teplota : " . $celsius . " °C";
            echo "<br>";
        } else if ($key == "pressure") {
            echo "&nbsp;&nbsp;&nbsp;Tlak : " . $val . " hPa";
            echo "<br>";
        } else if ($key == "humidity") {
            echo "&nbsp;&nbsp;&nbsp;Vlhkosť : " . $val . " %";
            echo "<br>";
        } else if ($key == "speed") {
            echo "&nbsp;&nbsp;&nbsp;Rýchlosť vetra : " . $val . " m/s";
            echo "<br>";
        } else if ($key == "all") {
            echo "&nbsp;&nbsp;&nbsp;Zamračené na : " . $val . " %";
            echo "<br>";
        } else if ($key == "id") {
            $city_id = $val;
        }
    }
}
echo "<br>";
echo "<div id=\"openweathermap-widget-15\"></div>
<script>window.myWidgetParam ? window.myWidgetParam : window.myWidgetParam = [];  window.myWidgetParam.push({id: 15,cityid: '" . $city_id . "',appid: '29c9b37830cac204fb1189070d5f213b',units: 'metric',containerid: 'openweathermap-widget-15',  });  (function() {var script = document.createElement('script');script.async = true;script.charset = \"utf-8\";script.src = \"//openweathermap.org/themes/openweathermap/assets/vendor/owm/js/weather-widget-generator.js\";var s = document.getElementsByTagName('script')[0];s.parentNode.insertBefore(script, s);  })();</script>";

?>
<hr>
</body>

</html>
