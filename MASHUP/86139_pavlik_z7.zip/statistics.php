<?php

function getUserIP()
{
    $client = @$_SERVER['HTTP_CLIENT_IP'];
    $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
    $remote = $_SERVER['REMOTE_ADDR'];

    if (filter_var($client, FILTER_VALIDATE_IP)) {
        $ip = $client;
    } elseif (filter_var($forward, FILTER_VALIDATE_IP)) {
        $ip = $forward;
    } else {
        $ip = $remote;
    }

    return $ip;
}

$ip = getUserIP();
$details = json_decode(file_get_contents("http://ipinfo.io/{$ip}/json"));


require_once "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// check connection
if ($conn->connect_error) {
    die("Connection failed : " . $conn . connect_error);
}

// GET CONTINENT
function ip_info($ip = NULL, $purpose = "location", $deep_detect = TRUE)
{
    $output = NULL;
    if (filter_var($ip, FILTER_VALIDATE_IP) === FALSE) {
        $ip = $_SERVER["REMOTE_ADDR"];
        if ($deep_detect) {
            if (filter_var(@$_SERVER['HTTP_X_FORWARDED_FOR'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
            if (filter_var(@$_SERVER['HTTP_CLIENT_IP'], FILTER_VALIDATE_IP))
                $ip = $_SERVER['HTTP_CLIENT_IP'];
        }
    }
    $purpose = str_replace(array("name", "\n", "\t", " ", "-", "_"), NULL, strtolower(trim($purpose)));
    $support = array("country", "countrycode", "state", "region", "city", "location", "address");
    $continents = array(
        "AF" => "Africa",
        "AN" => "Antarctica",
        "AS" => "Asia",
        "EU" => "Europe",
        "OC" => "Australia (Oceania)",
        "NA" => "North America",
        "SA" => "South America"
    );
    if (filter_var($ip, FILTER_VALIDATE_IP) && in_array($purpose, $support)) {
        $ipdat = @json_decode(file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip));
        if (@strlen(trim($ipdat->geoplugin_countryCode)) == 2) {
            switch ($purpose) {
                case "location":
                    $output = array(
                        "city" => @$ipdat->geoplugin_city,
                        "state" => @$ipdat->geoplugin_regionName,
                        "country" => @$ipdat->geoplugin_countryName,
                        "country_code" => @$ipdat->geoplugin_countryCode,
                        "continent" => @$continents[strtoupper($ipdat->geoplugin_continentCode)],
                        "continent_code" => @$ipdat->geoplugin_continentCode
                    );
                    break;
            }
        }
    }
    return $output;
}

//

$result = ip_info($ip, "Location");


$time_zone = getTimeZoneFromIpAddress();
// echo 'Your Time Zone is '.$time_zone;

function getTimeZoneFromIpAddress(){
    $clientsIpAddress = get_client_ip();

    $clientInformation = unserialize(file_get_contents('http://www.geoplugin.net/php.gp?ip='.$clientsIpAddress));

    $clientsLatitude = $clientInformation['geoplugin_latitude'];
    $clientsLongitude = $clientInformation['geoplugin_longitude'];
    $clientsCountryCode = $clientInformation['geoplugin_countryCode'];

    $timeZone = get_nearest_timezone($clientsLatitude, $clientsLongitude, $clientsCountryCode) ;

    return $timeZone;

}

function get_client_ip() {
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP'))
        $ipaddress = getenv('HTTP_CLIENT_IP');
    else if(getenv('HTTP_X_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    else if(getenv('HTTP_X_FORWARDED'))
        $ipaddress = getenv('HTTP_X_FORWARDED');
    else if(getenv('HTTP_FORWARDED_FOR'))
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    else if(getenv('HTTP_FORWARDED'))
        $ipaddress = getenv('HTTP_FORWARDED');
    else if(getenv('REMOTE_ADDR'))
        $ipaddress = getenv('REMOTE_ADDR');
    else
        $ipaddress = 'UNKNOWN';
    return $ipaddress;
}

function get_nearest_timezone($cur_lat, $cur_long, $country_code = '') {
    $timezone_ids = ($country_code) ? DateTimeZone::listIdentifiers(DateTimeZone::PER_COUNTRY, $country_code)
        : DateTimeZone::listIdentifiers();

    if($timezone_ids && is_array($timezone_ids) && isset($timezone_ids[0])) {

        $time_zone = '';
        $tz_distance = 0;

        //only one identifier?
        if (count($timezone_ids) == 1) {
            $time_zone = $timezone_ids[0];
        } else {

            foreach($timezone_ids as $timezone_id) {
                $timezone = new DateTimeZone($timezone_id);
                $location = $timezone->getLocation();
                $tz_lat   = $location['latitude'];
                $tz_long  = $location['longitude'];

                $theta    = $cur_long - $tz_long;
                $distance = (sin(deg2rad($cur_lat)) * sin(deg2rad($tz_lat)))
                    + (cos(deg2rad($cur_lat)) * cos(deg2rad($tz_lat)) * cos(deg2rad($theta)));
                $distance = acos($distance);
                $distance = abs(rad2deg($distance));
                // echo '<br />'.$timezone_id.' '.$distance;

                if (!$time_zone || $tz_distance > $distance) {
                    $time_zone   = $timezone_id;
                    $tz_distance = $distance;
                }

            }
        }
        return  $time_zone;
    }
    return 'unknown';
}


date_default_timezone_set($time_zone);
$date = new DateTime();
$date->modify('-21 minutes');
$dateString = $date->format('Y-m-d H:i:s');

$sql = "INSERT INTO INFO (PAGE, IP, LOGTIME, COUNTRY, FULLCOUNTRY, CITY)
VALUES ('3','" . $ip . "','" . $dateString . "','" . $details->country . "','" . $result[country] . "','" . $details->city . "')";

$conn->query($sql);

$page1 = 0;
$page2 = 0;
$page3 = 0;

$sixto14 = 0;
$fourteento20 = 0;
$twentyto24 = 0;
$twentyfourto6 = 0;

$sql = "SELECT * FROM INFO WHERE 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['PAGE'] == "1") {
            $page1++;
        } else if ($row['PAGE'] == "2") {
            $page2++;
        } else if ($row['PAGE'] == "3") {
            $page3++;
        }

        $t = $row['LOGTIME'];
        $arr = explode(" ", $t);
        $hour = substr($arr[1], 0, 2);

        if (($hour >= 6) && ($hour < 14)) {
            $sixto14++;
        } else if (($hour >= 14) && ($hour < 20)) {
            $fourteento20++;
        } else if (($hour >= 20) && ($hour < 24)) {
            $twentyto24++;
        } else if (($hour >= 0) && ($hour < 6)) {
            $twentyfourto6++;
        }
    }
}


$dataPoints = array(
    array("label" => "Informácie o počasí vo Vašej lokalite", "y" => $page1),
    array("label" => "Informácie o Vašej lokalite", "y" => $page2),
    array("label" => "Štatistiky", "y" => $page3)
);


$dataPoints2 = array(
    array("label" => "Počet návštev od 06:00 do 14:00", "y" => $sixto14),
    array("label" => "Počet návštev od 14:00 do 20:00", "y" => $fourteento20),
    array("label" => "Počet návštev od 20:00 do 24:00", "y" => $twentyto24),
    array("label" => "Počet návštev od 00:00 do 06:00", "y" => $twentyfourto6)
);

?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>Štatistiky</title>
    <meta charset="utf-8"/>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
    <script>

        window.onload = function () {

            var chart2 = new CanvasJS.Chart("chartContainer", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Štatistika návštevnosti stránky podľa času"
                },
                data: [{
                    type: "pie",
                    showInLegend: "true",
                    legendText: "{label}",
                    indexLabelFontSize: 16,
                    indexLabel: "{label} - #percent%",
                    dataPoints: <?php echo json_encode($dataPoints2, JSON_NUMERIC_CHECK); ?>
                }]
            });

            var chart = new CanvasJS.Chart("chartContainer2", {
                animationEnabled: true,
                exportEnabled: true,
                title: {
                    text: "Štatistika návštevnosti konkrétnych podstránok"
                },
                data: [{
                    type: "pie",
                    showInLegend: "true",
                    legendText: "{label}",
                    indexLabelFontSize: 16,
                    indexLabel: "{label} - #percent%",
                    dataPoints: <?php echo json_encode($dataPoints, JSON_NUMERIC_CHECK); ?>
                }]
            });

            chart2.render();
            chart.render();

        }


    </script>
</head>
<body>
<hr>
<ul>
    <li><a href="http://147.175.121.210:8111/cviko7/index.php">Informácie o počasí vo Vašej lokalite</a></li>
    <li><a href="http://147.175.121.210:8111/cviko7/visitor_info.php">Informácie o Vašej lokalite</a></li>
    <li><a href="">Štatistiky</a></li>
</ul>
<hr>
<h1>Štatistiky</h1>
<hr>


<?php

$sql = "SELECT * FROM INFO WHERE 1";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $countries = array();

    while ($row = $result->fetch_assoc()) {
        array_push($countries, $row['FULLCOUNTRY']);
    }
}

function array_count_values_of($value, $array)
{
    $counts = array_count_values($array);
    return $counts[$value];
}

echo "<h2>Návštevníci portálu a ich pôvod</h2>";
echo "<table id='dbTable'>";
echo "<tr><th>Vlajka</th><th>Štát</th><th>Počet jedinečných návštevníkov (1 IP adresa / 1 deň)</th></tr>";

while (!empty($countries)) {
    $countries = array_values($countries);


    $to_delete = $countries[0];
    $country_code = "";

    $sql = "SELECT * FROM INFO WHERE 1";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($row['FULLCOUNTRY'] == $to_delete) {
                $country_code = strtolower($row['COUNTRY']);
                break;
            }
        }
    }

    $unique_visit = 0;

    $sql = "SELECT * FROM INFO WHERE FULLCOUNTRY='" . $to_delete . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $times = array();
        $ip_addresses = array();

        while ($row = $result->fetch_assoc()) {
            if ($row['FULLCOUNTRY'] == $to_delete) {
                array_push($times, $row['LOGTIME']);
                array_push($ip_addresses, $row['IP']);
            }

        }
        if (count($ip_addresses) >= 1) {
            for ($i = 0; $i < count($ip_addresses); $i++) {

//                if (strtotime($times[$i]) < strtotime($times[$i + 1]) - (60 * 60 * 24)) {
//                    $unique_visit++;
//                }

                $next = $i + 1;
                if (count($ip_addresses) >= next) {

                    $num = array_count_values($ip_addresses);
                    $occurence_num = $num[$ip_addresses[$i]];

                    $match = false;
                    if ($occurence_num > 1) {

                        for ($j = $next; $j < count($ip_addresses); $j++) {

                            if ($ip_addresses[$i] == $ip_addresses[$j]) {
                                $arr = explode(" ", $times[$i]);
                                $arr2 = explode(" ", $times[$j]);

                                $match = true;
                                if ($arr[0] != $arr2[0]) {
                                    $unique_visit++;
                                }
                                break;
                            }
                        }

                        if ($match == false) {
                            $unique_visit++;
                        }
                    } else {
                        $unique_visit++;
                    }
                }

            }
        }
    }

    echo "<tr><th><img src='http://www.geonames.org/flags/x/" . $country_code . ".gif' height='20' width='25' alt='flag'></th><th><a href='country_info.php?country_code=" . $country_code . "'>" . $to_delete . "</a></th><th>" . $unique_visit . "</th></tr>";


    $i = 0;
    foreach ($countries as $one) {
        if ($one == $to_delete) {
            unset($countries[$i]);
        }
        $i++;
    }
}

echo "</table>";

echo "<br>";
echo "<hr>";


// MAP

$sql = "SELECT * FROM INFO WHERE 1";
$result = $conn->query($sql);
$country;
if ($result->num_rows > 0) {
    $countries = array();

    while ($row = $result->fetch_assoc()) {
        array_push($countries, $row['COUNTRY']);
    }
}

$max_visits = 0;
$max_visits_country = "";

while (!empty($countries)) {
    $countries = array_values($countries);

    $to_delete = $countries[0];


    $unique_visit = 0;

    $sql = "SELECT * FROM INFO WHERE COUNTRY='" . $to_delete . "'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $times = array();
        $ip_addresses = array();


        while ($row = $result->fetch_assoc()) {
            if ($row['COUNTRY'] == $to_delete) {
                array_push($times, $row['LOGTIME']);
                array_push($ip_addresses, $row['IP']);
            }
        }

        if (count($ip_addresses) >= 1) {
            for ($i = 0; $i < count($ip_addresses); $i++) {

                $next = $i + 1;
                if (count($ip_addresses) >= next) {

//                if (strtotime($times[$i]) < strtotime($times[$i + 1]) - (60 * 60 * 24)) {
//                    $unique_visit++;
//                }

                    $num = array_count_values($ip_addresses);
                    $occurence_num = $num[$ip_addresses[$i]];

                    $match = false;
                    if ($occurence_num > 1) {

                        for ($j = $next; $j < count($ip_addresses); $j++) {

                            if ($ip_addresses[$i] == $ip_addresses[$j]) {
                                $arr = explode(" ", $times[$i]);
                                $arr2 = explode(" ", $times[$j]);

                                $match = true;
                                if ($arr[0] != $arr2[0]) {
                                    $unique_visit++;
                                }
                                break;
                            }
                        }

                        if ($match == false) {
                            $unique_visit++;
                        }
                    } else {
                        $unique_visit++;
                    }
                }
            }
        }
    }

    if ($unique_visit > $max_visits) {
        $max_visits = $unique_visit;
        $max_visits_country = $to_delete;
    }

    $i = 0;
    foreach ($countries as $one) {
        if ($one == $to_delete) {
            unset($countries[$i]);
        }
        $i++;
    }
}

$sql = "SELECT * FROM INFO WHERE 1";
$result = $conn->query($sql);
$country;
$cities = array();
$fullcntry;

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        if ($row['COUNTRY'] == $max_visits_country) {
            array_push($cities, $row['CITY']);
            $fullcntry = $row['FULLCOUNTRY'];
        }
    }
}

$data = "['Mesto',   'Počet návštev'],[";
while (!empty($cities)) {
    $cities = array_values($cities);

    $to_delete = $cities[0];
    $occurence = array_count_values_of($to_delete, $cities);


    if (count(array_unique($cities)) > 1) {
        $data .= "'" . $to_delete . "'," . $occurence . "],[";
    } else {
        $data .= "'" . $to_delete . "'," . $occurence;
    }


    $i = 0;
    foreach ($cities as $one) {
        if ($one == $to_delete) {
            unset($cities[$i]);
        }
        $i++;
    }
}
$data .= "]";

echo "<h2>Najviac jedinečných návštevníkov bolo z krajiny " . $fullcntry . "</h2>";

echo "    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type='text/javascript'>
        google.charts.load('current', {
            'packages': ['geochart'],
            // Note: you will need to get a mapsApiKey for your project.
            // See: https://developers.google.com/chart/interactive/docs/basic_load_libs#load-settings
            'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
        });
        google.charts.setOnLoadCallback(drawMarkersMap);

        function drawMarkersMap() {
            var data = google.visualization.arrayToDataTable([
                " . $data . "
            ]);

            var options = {
                region: '" . $max_visits_country . "',
                displayMode: 'markers',
                colorAxis: {colors: ['red', 'green']}
            };

            var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        };
    </script>";

?>
<div id="chart_div" style="height: 370px; width: 40%; margin-left: 30%;"></div>
<hr>
<div id="chartContainer" style="height: 370px; width: 60%; margin-left: 20%; background-color: #c2e9ff"></div>
<hr>
<div id="chartContainer2" style="height: 370px; width: 60%; margin-left: 20%; background-color: #c2e9ff"></div>
<hr>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>
