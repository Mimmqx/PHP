<!DOCTYPE HTML>
<head>
    <title>Individual info</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php
$country_code = htmlspecialchars($_GET["country_code"]);

require_once "config.php";
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8");

// check connection
if ($conn->connect_error) {
    die("Connection failed : " . $conn . connect_error);
}

$sql = "SELECT * FROM INFO WHERE 1";
$result = $conn->query($sql);
$country;
if ($result->num_rows > 0) {
    $cities = array();

    while ($row = $result->fetch_assoc()) {
        if (strtolower($row['COUNTRY']) == $country_code) {
            array_push($cities, $row['CITY']);
            $country = $row['FULLCOUNTRY'];
        }
    }
}

function array_count_values_of($value, $array)
{
    $counts = array_count_values($array);
    return $counts[$value];
}

echo "<h2>Návštevníci portálu zo štátu " . $country . "</h2>";
echo "<table id='dbTable'>";
echo "<tr><th>Vlajka</th><th>Mesto</th><th>Počet návštev</th></tr>";

$data = "['Mesto',   'Počet návštev'],[";

while (!empty($cities)) {
    $cities = array_values($cities);

    $to_delete = $cities[0];
    $occurence = array_count_values_of($to_delete, $cities);

    if (count(array_unique($cities)) > 1) {
        $data .= "'" . $to_delete . "'," . $occurence . "],[";
    } else {
        $data .= "'" . $to_delete . "'," . $occurence;
    }



    if ($to_delete == "") {
        $to_delete = "Nelokalizované mestá a vidiek";
        echo "<tr><th><img src='http://www.geonames.org/flags/x/" . $country_code . ".gif' height='20' width='25' alt='flag' ></th><th>" . $to_delete . "</th><th>" . array_count_values_of("", $cities) . "</th></tr>";
        $to_delete = $cities[0];
    } else {
        echo "<tr><th><img src='http://www.geonames.org/flags/x/" . $country_code . ".gif' height='20' width='25' alt='flag' ></th><th>" . $to_delete . "</th><th>" . array_count_values_of($to_delete, $cities) . "</th></tr>";
    }

    $i = 0;
    foreach ($cities as $one) {
        if ($one == $to_delete) {
            unset($cities[$i]);
        }
        $i++;
    }
}
$data .= "]";


echo "</table>";
echo "<br>";


echo "    <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type='text/javascript'>
        google.charts.load('current', {
            'packages': ['geochart'],
            'mapsApiKey': 'AIzaSyD-9tSrke72PouQMnMX-a7eZSW0jkFMBWY'
        });
        google.charts.setOnLoadCallback(drawMarkersMap);

        function drawMarkersMap() {
            var data = google.visualization.arrayToDataTable([
                " . $data . "
            ]);

            var options = {
                region: '" . strtoupper($country_code)  . "',
                displayMode: 'markers',
                colorAxis: {colors: ['red', 'green']}
            };

            var chart = new google.visualization.GeoChart(document.getElementById('chart_div'));
            chart.draw(data, options);
        };
    </script>";


?>
<br>
<div id="chart_div" style="height: 370px; width: 40%; margin-left: 30%;"></div>

<br>
<a href="#" id="bottle" onclick="document.location='http://147.175.121.210:8111/cviko7/statistics.php';return false;"
   class="returnSign">
    <img src="arrowBack.png" alt="back" class="clickable" title="Späť na štatistiky"
         height=50 width=50 style="margin-left: 49%">
</a>


</body>
</html>
