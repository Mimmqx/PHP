<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>Údaje o reprezentantovi</h2>
<div>
<form action="index.php" method="post" enctype='multipart/form-data'>
    Name:<br>
    <input type="text" name="name" value="" placeholder="Name">
    <br>
    Surname:<br>
    <input type="text" name="surname" value="" placeholder="Surname">
    <br>
    Date of birth:<br>
    <input type="text" name="datebirth" value="" placeholder="DD.MM.YYYY">
    <br>
    Place of birth:<br>
    <input type="text" name="placebirth" value="" placeholder="City">
    <br>
    Country of birth:<br>
    <input type="text" name="countryofbirth" value="" placeholder="Country">
    <br>
    Date of death:<br>
    <input type="text" name="dateofdeath" value="" placeholder="DD.MM.YYYY">
    <br>
    Place of death:<br>
    <input type="text" name="placeofdeath" value="" placeholder="City">
    <br>
    Country of death:<br>
    <input type="text" name="countryofdeath" value="" placeholder="Country">
    <br>
    <h2>Údaje o umiestnení reprezentanta</h2>
    Place:<br>
    <input type="text" name="place" value="" placeholder="City">
    <br>
    Discipline:<br>
    <input type="text" name="discipline" value="" placeholder="Discipline">
    <br>
    ID_Person:<br>
    <input type="text" name="id_person" value="" placeholder="OH">
    <br>
    ID_OH:<br>
    <input type="text" name="OH" value="" placeholder="OH">
    <br>
    <input type="submit" name="update" onclick="myFunction()">
</form>
</div>
<?php
$firstname = $_POST["name"];
$surname = $_POST["surname"];
$dateofbirth = $_POST["datebirth"];
$placeofbirth = $_POST["placebirth"];
$countryofbirth = $_POST["countryofbirth"];
$dateofdeath = $_POST["dateofdeath"];
$placeofdeath = $_POST["placeofdeath"];
$countryofdeath = $_POST["countryofdeath"];
$place= $_POST["place"];
$discipline= $_POST["discipline"];

echo $firstname;
?>
<div class="content">
    <?php
    echo "<table  class=\"table table-hover table-bordered sortable\" id='file-table'>";


    echo "<thead> <tr><th>ID</th><th>Typ</th><th>Rok</th><th>Poradie</th><th>Mesto</th><th>Krajina</th></tr></thead> <tbody>";

    class TableRows extends RecursiveIteratorIterator {
        function __construct($it) {
            parent::__construct($it, self::LEAVES_ONLY);
        }

        function current() {
            return "<td style='width:150px;border:1px solid black;'>" . parent::current(). "</td>";
        }

        function beginChildren() {
            echo "<tr>";
        }

        function endChildren() {
            echo "</tr>" . "\n";
        }
    }

    include 'config.php';

    try {

        $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $stmt = $conn->prepare("SELECT * FROM oh");
        $stmt->execute();

// set the resulting array to associative
        $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
        foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
            echo $v;
        }
    }
    catch(PDOException $e) {
        echo "Error: " . $e->getMessage();
    }
    $conn = null;
    echo "</table>";
    ?>

</body>
</html>