<?php
$page = $_SERVER['PHP_SELF'];
$sec = "2";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="refresh" content="<?php echo $sec?>;URL='<?php echo $page?>'">
    <link rel="stylesheet" href="style.css">
    <script src="sort.js" async></script>
    <script src="reload.js" async></script>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
</head>
<body>

<a class="w3-button w3-black" href="top10.php" target="_blank">TOP 10</a>
<a class="w3-button w3-black" href="insertData.php" target="_blank">Load Data</a>
<div class="content">
<?php
session_start();
echo "<table  class=\"table table-hover table-bordered sortable\" id='file-table'>";
echo "<thead> <tr><th>ID</th><th>Meno</th><th>Priezvisko</th><th>Rok</th><th>Mesto</th><th>Typ</th><th>Disciplína</th><th>Vymazanie</th></tr></thead> <tbody>";

class TableRows extends RecursiveIteratorIterator {
    function __construct($it) {
        parent::__construct($it, self::LEAVES_ONLY);
    }

    function current() {
        return "<td style='width:150px;border:1px solid black;'>" . parent::current()."</td>";
    }

    function beginChildren() {
        echo "<tr>";
    }

    function endChildren() {

        echo "<td>" . '<input parentrow_id=\'<php echo $pack[id];?>\' name="edit_pack" type="button" value="Edit" onclick="javascript:edit_pack(this.parentrow_id)"/>' . "</td>" .  "</tr>" . "\n";
    }

}

include 'config.php';

try {
    $pocet = 0;
    $conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT os.id_person,os.name, os.surname, oh.year, oh.city, oh.type, um.discipline FROM oh oh, osoby os, umiestnenia um WHERE os.id_person = um.id_person AND oh.id_OH = um.ID_OH AND um.place = '1'");
    $stmt1 = $conn->prepare("SELECT id_person FROM osoby");
    $stmt->execute();
    $stmt1->execute();
    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);
    $result = $stmt1->setFetchMode(PDO::FETCH_ASSOC);
//    foreach (array_column($result, 'id_person') as $id) {
//        echo $id;
//    }

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) {
        echo $v;
        echo array_column($v, 'person_id');
    }

//   $result1 = $stmt1->setFetchMode(PDO::FETCH_ASSOC);
//   foreach(new TableRows(new RecursiveArrayIterator($stmt1->fetchAll())) as $k=>$v) {
//       echo $v;
//   }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";

$firstname = $_POST["name"];
$surname = $_POST["surname"];
$dateofbirth = $_POST["datebirth"];
$placeofbirth = $_POST["placebirth"];
$countryofbirth = $_POST["countryofbirth"];
$dateofdeath = $_POST["dateofdeath"];
$placeofdeath = $_POST["placeofdeath"];
$countryofdeath = $_POST["countryofdeath"];
$place = $_POST["place"];
$discipline = $_POST["discipline"];
$OH = $_POST["OH"];
$ID = $_POST["id_person"];

//$result1 = $stmt1->setFetchMode(PDO::FETCH_ASSOC);
//foreach(new TableRows(new RecursiveArrayIterator($stmt1->fetchAll())) as $k=>$v) {
//    //echo $v;
//}

//$_SESSION['data'] = 30;
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update'])) {
        include 'post.php';
    /* ... SQL EXECUTION TO UPDATE DB ... */

    echo "<script>window.close();</script>";

    }
    else if(isset($_POST['Back'])){
        echo "<script>window.close();</script>";
    }
}
?>
</div>
</body>
</html>

