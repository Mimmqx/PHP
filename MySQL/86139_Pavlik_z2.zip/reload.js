function myFunction() {
    location.reload();
}
function edit_pack() {
    alert(this.parentNode.parentNode.id);
}