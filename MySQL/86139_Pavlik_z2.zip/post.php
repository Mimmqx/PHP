<?php
try {
    $conn1 = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    // set the PDO error mode to exception
    $conn1->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $sql1 = "INSERT INTO osoby (id_person,name,surname,birthDay,birthCountry,deathPlace,deathDay,deathCountry,birthPlace)
    VALUES ('$ID','$firstname', '$surname', '$dateofbirth','$countryofbirth','$placeofdeath','$dateofdeath','$countryofdeath','$placeofbirth')";
    $sql2 = "INSERT INTO umiestnenia (id_person,ID_OH,place,discipline)
    VALUES ('$ID','$OH','$place','$discipline')";
    // use exec() because no results are returned
    $conn1->exec($sql1);
    $conn1->exec($sql2);
    echo "New record created successfully";

}
catch(PDOException $e)
{
    echo $sql1 . "<br>" . $e->getMessage();
    echo $sql2 . "<br>" . $e->getMessage();
}
//include 'post.php';
$conn = new PDO("mysql:host=$servername;dbname=$dbname;charset=utf8", $username, $password);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$stmt2 = $conn->prepare("SELECT * FROM osoby");
$stmt2->execute();
$result = $stmt2->setFetchMode(PDO::FETCH_ASSOC);
foreach(new TableRows(new RecursiveArrayIterator($stmt2->fetchAll())) as $k=>$v) {
 //   echo $v;
}
//echo '<script type="text/javascript">',
//' location.reload();',
//'</script>'
//;
?>
