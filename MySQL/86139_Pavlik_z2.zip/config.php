<?php header('Content-Type: text/html; charset=utf-8');
$config=array(
    $servername = "localhost",
$username = "xpavlikm3",
$password = "Feistujebem123",
$dbname = "zadanie2"
);
?>