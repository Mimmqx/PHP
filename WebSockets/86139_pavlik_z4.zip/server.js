var server = require('websocket').server, http = require('http');

var socket = new server({
    httpServer: http.createServer().listen(9000)
});

//socket.io

var counter = 0;
var clients = [];

socket.on('request', function(request) {
    var connection = request.accept(null, request.origin);
    clients[counter] = connection;
	
	
	
	console.log("Connected: "+connection.remoteAddresses);
    connection.id = counter;

    counter++;

    connection.on('message', function(message) {
        console.log(message.utf8Data);
        for (index in clients){
            if(clients[index].id != connection.id){
                clients[index].send(JSON.stringify(message));
            }
        }
    });

    connection.on('close', function() {
		console.log("Disconnected: "+connection.remoteAddresses);
		setTimeout(function(){ delete clients[connection.id]; }, 1);
 
    });
}); 