<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Zadanie 4 - WebSockets</title>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">    <link href="https://fonts.googleapis.com/css?family=Pacifico|Ubuntu" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="container">
<div class="row">
    <div class="col-12 text-center my-3,move">
        <select name="" id="color" class="w-25">
            <option>Red</option>
            <option>Green</option>
            <option>Blue</option>
            <option>Orange</option>
            <option>Yellow</option>
            <option>Black</option>
            <option>Pink</option>
            <option>Cyan</option>
        </select>
    </div>
    <div class="col mb-4">
        <canvas id="canvas" width="500" height="500">

        </canvas>
    </div>

    <div class="col-12" id="down_cont">
        <a id="downlaod" href="" download="Canvas" title="ImageName">
            Stiahnuť obrázok
            <img hidden download="Canvas.png" id="canvasimg" src=""  alt="Canvas"/>
        </a>
    </div>
    <div class="col-12" id="down_cont">
        <a href="index.php" id="downlaod" title="ImageName">Vyčisti obrázok<a/>
    </div>
</div>



</div>
<div id="canvas_container">
    <script type="text/javascript">
        $('#downlaod').click(function () {
            $("#canvasimg").attr("src", $("#canvas").get(0).toDataURL("img/png"));
            $("#downlaod").attr("href", $("#canvas").get(0).toDataURL("img/png"));
        });
    </script>
</div>

<script>


    context = document.getElementById("canvas").getContext("2d");
    var colorPurple = "#cb3594";
    var colorGreen = "#659b41";
    var colorYellow = "#ffcf33";
    var colorBrown = "#986928";
    var colorOrange = "#ffa500"

    var curColor = colorPurple;
    var clickColor = new Array();

    $("#color").change(function () {
        curColor = $(this).val();
    });

    $('#canvas').mousedown(function(e){
        var elm = $(this);
        var mouseX = e.pageX - elm.offset().left;
        var mouseY = e.pageY - elm.offset().top;

        console.log(mouseX+":"+mouseY);

        paint = true;
        addClick(mouseX, mouseY);

        redraw();
    });
    $('#canvas').mousemove(function(e){
        var elm = $(this);
        var mouseX = e.pageX - elm.offset().left;
        var mouseY = e.pageY - elm.offset().top;

        if(paint){
            addClick(mouseX, mouseY, true);
            redraw();
        }
    });
    $('#canvas').mouseup(function(e){
        paint = false;
    });
    $('#canvas').mouseleave(function(e){
        paint = false;
    });
    var clickX = new Array();
    var clickY = new Array();
    var clickDrag = new Array();
    var paint;
    


    function addClick(x, y, dragging)
    {
        clickX.push(x);
        clickY.push(y);
        var data = {'id':3,'X':x,'Y':y,'drag':dragging,'color':curColor};
        socket.send(JSON.stringify(data));
        clickDrag.push(dragging);
        clickColor.push(curColor);
    }
    function redraw(){
        context.clearRect(0, 0, context.canvas.width, context.canvas.height); // Clears the canvas

        context.strokeStyle = "#df4b26";
        context.lineJoin = "round";
        context.lineWidth = 5;

        for(var i=0; i < clickX.length; i++) {
            context.beginPath();
            if(clickDrag[i] && i){
                context.moveTo(clickX[i-1], clickY[i-1]);
            }else{
                context.moveTo(clickX[i]-1, clickY[i]);
            }
            context.lineTo(clickX[i], clickY[i]);
            context.strokeStyle = clickColor[i];
            context.closePath();
            context.stroke();
        }
    }
</script>

<script type="application/javascript">


    var content = document.getElementById('content');
    var socket = new WebSocket('ws://147.175.121.210:9111');

    socket.onmessage = function (message) {
        var data = JSON.parse(JSON.parse(message.data).utf8Data);


            clickX.push(data.X);
            clickY.push(data.Y);
            clickDrag.push(data.drag);
            clickColor.push(data.color);
            redraw();
        
    };

    socket.onerror = function (error) {
        console.log('WebSocket error: ' + error);
    };
</script>
</body>
</html>