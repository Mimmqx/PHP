<?php
session_start(); 
//include 'dbh.php';
include 'header.php';
include_once 'simple_html_dom.php';
mysqli_set_charset($conn, "utf8");

$url = "https://is.stuba.sk/lide/clovek.pl";
$data = array (
  'lang' => 'sk',
  'zalozka' => '5',
  'id'=>  $_SESSION['uid'], /*'4948' ,*/
  'rok'=> '1',
  'order_by' => 'typ_rok_naz'
  );

$params = '';

foreach($data as $key=>$value)
  $params .= $key.'='.$value.'&';

$params = trim($params, '&');
$ch = curl_init ();

curl_setopt($ch, CURLOPT_URL, $url.'?'.$params );
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

$returndata = curl_exec ($ch);

$html = new simple_html_dom();
$html->load($returndata);

$i=0;

$druhy_prace = array('monografie, učebnice, skriptá, príručky, normy, patenty, výskumné správy, iné neperiodické publikácie',
                    'články v&nbsp;časopisoch',
                    'príspevky v&nbsp;zborníkoch, kapitoly v&nbsp;monografiách/učebniciach, abstrakty'                   
                    );

echo "<br><br><h3 style='color: white;'>Publikácie užívateľa: ".$_SESSION['meno']."</h3><br>";
echo "<table id='publikacie'><tr><th>Por.</th>  <th>Publikácie</th>  <th>Druh výsledku</th>  <th>Rok</th></tr>";

foreach($html->find('tr') as $element){ 
  $cislo =  $element->children(0)->plaintext;
  $publikacia = $element->children(1)->plaintext;
  $druh = $element->children(2)->plaintext;
  $rok = $element->children(3)->plaintext;

  if($druhy_prace[0] == $druh || $druhy_prace[1] == $druh || $druhy_prace[2] == $druh){
    if($rok > '2012' && $cislo !='Por.'){
        echo "<tr>
                <td>".$cislo."</td>
                <td>".$publikacia."</td>
                <td>".$druh."</td><td>".$rok."</td>
              </tr>";
    }
  }

}
  echo "</table>";
?>


<script type="text/javascript">sortTable2();</script>
