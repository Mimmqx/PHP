<?php 
include 'header.php';


echo "<p style='color: white;'>Vitajte na stránke!</p>";