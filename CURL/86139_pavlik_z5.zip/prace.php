<?php 
include 'header.php';
include 'simple_html_dom.php';
mysqli_set_charset($conn, "utf8");
///http://agichevski.com/2014/01/21/php-curl-post-and-get-methods/

$ustav = $_POST['vyber_ustavu'];
$typ_prace = $_POST['vyber_prace'];
$radio = $_POST['radio'];

$data = array (
        'lang' => 'sk',
        'pracoviste' => $ustav
        );

$params = '';
    foreach($data as $key=>$value)
                $params .= $key.'='.$value.'&';
         
      $params = trim($params, '&');

$url = "https://is.stuba.sk/pracoviste/prehled_temat.pl";

$ch = curl_init ();
curl_setopt($ch, CURLOPT_URL, $url.'?'.$params);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

$returndata = curl_exec ($ch);
curl_close($ch);

$html = new simple_html_dom();
$html->load($returndata);

echo "<div id='volne_prace'>
    <input type='text' id='filter_skolitel' onkeyup='filterSkolitel()' placeholder='filter školiteľa..'>
    <input type='text' id='filter_program' onkeyup='filterProgram()' placeholder='filter programu..'>
    <h3 style='color: white;'>Zoznam voľných tém na záverčnú prácu</h3>

    <table>
      <tr><th onclick='sortTable(0)'>Názov</th>
      	  <th onclick='sortTable(1)'>Školiteľ</th>
      	  <th onclick='sortTable(2)'>Program</th>
      	  <th onclick='sortTable(3)'>Obsadenosť</th>
      	  <th onclick='sortTable(4)'>Študent</th>
      	  <th onclick='sortTable(5)'>Ročník</th>
      </tr>";

 foreach($html->find('tr') as $element){
    //    echo $element->children(9);
    // && $element->children(9)->plaintext == "--"
    	if( $element->children(1)->plaintext == $typ_prace && $radio == "free" && ((strpos($element->children(9),"--") !== false) || (strpos($element->children(9),"0 / 1") !== false) || (strpos($element->children(9),"0 / 2") !== false)|| (strpos($element->children(9),"1 / 2") !== false))){
            //echo $radio;
    	   // echo $element->children(10)->plaintext;
            $nazov = $element->children(2)->plaintext;
          //  echo $nazov ;
          //  var_dump($nazov);
            $skolitel = $element->children(3)->plaintext;
            $program = $element->children(5)->plaintext;
            $obsadenost = $element->children(9)->plaintext;
            $student = $element->children(10)->plaintext;
            $annotationURL = 'https://is.stuba.sk'.$element->children(8)->children(0)->children(0)->getAttribute('href');
          $ch = curl_init($annotationURL);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
          $result = curl_exec($ch);
          curl_close($ch);

          $doc = new DOMDocument();
          libxml_use_internal_errors(true);
          $doc->loadHTML($result);
          $xPath = new DOMXPath($doc);
          $annotation = $xPath->query('//html/body/div/div/div/table[1]/tbody/tr[last()]/td[last()]')[0]->textContent;


            $annotationURL1 = $element->children(10)->plaintext;
         // echo $nazov;
          echo "<tr>
                  <td class='clickable'>".$nazov."<div id='okno' style='display: none;'>".$annotation."</div></td>
                  <td>".$skolitel."</td>
                  <td>".$program."</td>
                  <td>".$obsadenost."</td>
                  <td>".$student."</td>

              </tr>";
    	}
    	else if($element->children(1)->plaintext == $typ_prace && $radio == "not_free" && (strpos($element->children(9),"--") != true) &&(strpos($element->children(9),"0") != true)){
            $nazov = $element->children(2)->plaintext;
            $skolitel = $element->children(3)->plaintext;
            $program = $element->children(5)->plaintext;
            $obsadenost = $element->children(9)->plaintext;
            $student = $element->children(10)->plaintext;
            $annotationURL = 'https://is.stuba.sk'.$element->children(8)->children(0)->children(0);
            $ch = curl_init($annotationURL);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
            $result = curl_exec($ch);
            curl_close($ch);

            $doc = new DOMDocument();
            libxml_use_internal_errors(true);
            $doc->loadHTML($result);
            $xPath = new DOMXPath($doc);
            $annotation = $xPath->query('//html/body/div/div/div/table[1]/tbody/tr[last()]/td[last()]')[0]->textContent;

            $annotationURL1 = $element->children(10)->children(0)->children(0)->getAttribute('href');
            //$ID="";
            $matches="";
            preg_match_all('!\d+!', $annotationURL1, $matches);
            //print_r($matches);

            $ID = "http://is.stuba.sk/lide/clovek.pl?lang=sk;id=".$matches[0][0];
            $chid = curl_init ();
            curl_setopt($chid, CURLOPT_URL, $ID);
            curl_setopt($chid, CURLOPT_RETURNTRANSFER, 1);

            $returndata1 = curl_exec ($chid);
            curl_close($chid);

            $htmlid = new simple_html_dom();
            $htmlid->load($returndata1);
            $ID2 = "";
            foreach($htmlid->find('tr') as $element1){
               // echo $element1->children(1)->plaintext;
                echo "skap";

            }
            echo "<tr>
                  <td class='clickable'>".$nazov."<div id='okno' style='display: none;'>".$annotation."</div></td>
                  <td>".$skolitel."</td>
                  <td>".$program."</td>
                  <td>".$obsadenost."</td>
                  <td>".$student."</td>
                  <td>".$ID."</td>
              </tr>";
        }
    }
echo "</table></div>";



?>
