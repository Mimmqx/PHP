<?php
session_start(); //session start
   include 'header.php';
    include 'footer.php';
    mysqli_set_charset($conn, "utf8");

$ldapuid = $_POST['username'];

$basedn  = 'ou=People, DC=stuba, DC=sk';
$ds = @ldap_connect('ldap://ldap.stuba.sk', 636);
@ldap_set_option($ds, LDAP_OPT_PROTOCOL_VERSION, 3);

 $ldapFilter = array("uid", "uisid", "cn", "givenname","surname","mail");

 $ldapSearchResult = @ldap_search($ds, $basedn, 'uid='.$ldapuid, $ldapFilter);

 if ($ldapSearchResult) {
  $result = @ldap_get_entries($ds, $ldapSearchResult);
  $uid = $result[0]['uisid'][0];
  $meno = $result[0]['cn'][0]; 
  @ldap_close($ds); 

  $_SESSION['uid'] = $uid;
  $_SESSION['meno'] = $meno;
  }
   if (isset($_SESSION['uid'])) {
      header("Location: publikacie.php");
    }


?>



