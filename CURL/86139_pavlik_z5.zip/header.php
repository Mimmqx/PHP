<?php
 session_start();
 mysqli_set_charset($conn, "utf8");
?>

<!DOCTYPE HTML>
<html lang="sk">
  <head>
    <title>Curl</title>
    <meta content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="style.css">
    
    <script src='https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js'></script>
    <script type="text/javascript" src="script.js"></script>

  </head>
  <body> 
<header>
	<h2>Curl</h2>
</header>


<form action="prace.php" method="post" id="formular">
  <select name="vyber_prace" id="vyber_prace">
    <option value="BP">Bakalárska práca</option>
    <option value="DP">Diplomová práca</option>
    <option value="DizP">Dizertačná práca</option>
  </select>

  <select name="vyber_ustavu" id="vyber_ustavu">
      <option value="642">Ústav automobilovej mechatroniky</option>
      <option value="548">Ústav elektroenergetiky a aplikovanej elektrotechniky</option>
      <option value="549">Ústav elektroniky a fotoniky</option>
      <option value="550">Ústav elektrotechniky</option>
      <option value="816">Ústav informatiky a matematiky</option>
      <option value="817">Ústav jadrového a fyzikálneho inžinierstva</option>
      <option value="818">Ústav multimediálnych informačných a komunikačných technológií</option>
      <option value="356">Ústav robotiky a kybernetiky</option>
    </select>

    <br>

        <input type="radio" name="radio" value="free" checked="true"> <p>Voľné témy</p><br>
        <input type="radio" name="radio" value="not_free"><p>Obsadené témy</p><br>

    <button class='button button2'";>Potvrdiť</button>

</form>

<div>
    <form id='ldapform' action='ldap.php' method='POST'>
      <input type='text' name='username' placeholder='Login(AIS)'>
      <button class='button button2' type='submit'>Vyhľadať</button>
    </form>
 </div>

