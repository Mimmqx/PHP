<!DOCTYPE html>
<head>
    <link rel="stylesheet" href="style.css">
    <title>REST</title>
</head>
<body>

<?php


echo "<h1>REST</h1>";
echo "<hr>";
echo "<form id=\"date\" method=\"post\" action=\"index.php\">

    <label>Zadajte deň a mesiac<input placeholder=\"dd.mm.\" type=\"text\" name=\"datum\"></label>
    <input type=\"submit\" value=\"Získať mena ľudí, ktorý oslavujú v tento deň meniny na Slovensku a v Českej republike\">
</form>";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        if (isset($_POST['datum'])) {
            echo "<div id='first'></div>";
            $myArray = explode('.', $_POST['datum']);
            $date = $myArray[1] . $myArray[0];

//    $url = 'http://147.175.98.184/z6_restfulll/meniny.xml';
//    $xml = simplexml_load_file($url) or die("feed not loading");
//    foreach ($xml->zaznam as $zaznam) {
//        if ((string)$zaznam->den == (string)$date) {
//            echo "Na Slovensku má meniny " . $zaznam->SK;
//        }
//    }

            echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
    <script>
            $(\"#first\").append(\"<h2></h2>\");
            $(\"<h2></h2>\").html('" . $_POST['datum'] . "').appendTo(\"#first h2\");
            $(\"#first\").append(\"<ul></ul>\");
            $.ajax({
                type: \"GET\",
                url: \"meniny.xml\",
                dataType: \"xml\",
                success: function (xml) {
                    $(xml).find('zaznam').each(function () {
                        var dat = $(this).find('den').text();
                        var name = $(this).find('SK').text();
                        var czName = $(this).find('CZ').text();
                        if(dat == '" . $date . "'){
                            $(\"<li></li>\").html('Na Slovensku má meniny '+name).appendTo(\"#first ul\");
                            $(\"<li></li>\").html('V Česku má meniny '+czName).appendTo(\"#first ul\");
                        }
                    });
                },
                error: function () {
                    alert(\"An error occurred while processing XML file.\");
                }
            });

    </script>";

        }
}
echo "<hr>";


echo "<form id=\"textWithState\" method=\"post\" action=\"index.php\">

    <label>Zadajte meno<input placeholder=\"Sem zadajte meno\" type=\"text\" name=\"name\"></label>
    <label>Vyberte krajinu
        <select name=\"countries\">
            <option value=\"SK\">Slovenská republika</option>
            <option value=\"CZ\">Česká republika</option>
            <option value=\"HU\">Maďarsko</option>
            <option value=\"PL\">Poľsko</option>
            <option value=\"AT\">Rakúsko</option>
        </select>
    </label>
    <input type=\"submit\" value=\"Získať deň a mesiac, kedy oslavuje človek s daným menom vo zvolenej krajine meniny\">
</form>";

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        if ((isset($_POST['name'])) && ($_POST['name'] != "")) {
            echo "<div id='second'></div>";

            echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
    <script>


            $(\"#second\").append(\"<ul></ul>\");
            $.ajax({
                type: \"GET\",
                url: \"meniny.xml\",
                dataType: \"xml\",
                success: function (xml) {
                    $(xml).find('zaznam').each(function () {
                        var dat = $(this).find('den').text();
                        var name = $(this).find('" . $_POST['countries'] . "').text();
                        var parts = name.split(\",\");
                        var includes = false;
                        var monthDay = dat.substr(2, 2)+ '.' + dat.substr(0, 2)+'.';
                        parts.forEach(function(part) {
                            if (part == '" . $_POST['name'] . "'){
                                includes = true;
                            }
                        });
                        if(includes){
                            $(\"<li></li>\").html('V krajine " . $_POST['countries'] . " má " . $_POST['name'] . " meniny '+monthDay).appendTo(\"#second ul\");
                        }
                    });
                },
                error: function () {
                    alert(\"An error occurred while processing XML file.\");
                }
            });

    </script>";
        }
}
echo "<hr>";

echo "<form id=\"sviatkySK\" method=\"post\" action=\"index.php\">
        <input type=\"submit\" name=\"sviatkySK\" value=\"Zobraziť všetky slovenské sviatky\" />
        </form>";
echo "<form id=\"sviatkyCZ\" method=\"post\" action=\"index.php\">
        <input type=\"submit\" name=\"sviatkyCZ\" value=\"Zobraziť všetky české sviatky\" />
        </form>";
echo "<form id=\"dniSK\" method=\"post\" action=\"index.php\">
        <input type=\"submit\" name=\"dniSK\" value=\"Zobraziť všetky pamätné dni na SLovensku\" />
        </form>";

echo "<br>";
echo "<div id='third'></div>";
$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'POST':
        if (isset($_POST['sviatkySK'])) {

            echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
    <script>
            $(\"#third\").append(\"<h2></h2>\");
            $(\"<h2></h2>\").html('Slovenské sviatky').appendTo(\"#third h2\");
            $(\"#third\").append(\"<ul></ul>\");
            $.ajax({
                type: \"GET\",
                url: \"meniny.xml\",
                dataType: \"xml\",
                success: function (xml) {

                    $(xml).find('zaznam').each(function () {
                        var dat = $(this).find('den').text();
                        var name = $(this).find('SKsviatky').text();
                        var monthDay = dat.substr(2, 2)+ '.' + dat.substr(0, 2)+'.';
                        if(name != ''){
                            $(\"<li></li>\").html(monthDay + ' - ' + name).appendTo(\"#third ul\");
                        }
                        
                    });
                },
                error: function () {
                    alert(\"An error occurred while processing XML file.\");
                }
            });

    </script>";
        } else if (isset($_POST['sviatkyCZ'])) {
            echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
    <script>
            $(\"#third\").append(\"<h2></h2>\");
            $(\"<h2></h2>\").html('České sviatky').appendTo(\"#third h2\");
            $(\"#third\").append(\"<ul></ul>\");
            $.ajax({
                type: \"GET\",
                url: \"meniny.xml\",
                dataType: \"xml\",
                success: function (xml) {

                    $(xml).find('zaznam').each(function () {
                        var dat = $(this).find('den').text();
                        var name = $(this).find('CZsviatky').text();
                        var monthDay = dat.substr(2, 2)+ '.' + dat.substr(0, 2)+'.';
                        if(name != ''){
                            $(\"<li></li>\").html(monthDay + ' - ' + name).appendTo(\"#third ul\");
                        }
                        
                    });
                },
                error: function () {
                    alert(\"An error occurred while processing XML file.\");
                }
            });

    </script>";
        } else if (isset($_POST['dniSK'])) {
            echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
    <script>
            $(\"#third\").append(\"<h2></h2>\");
            $(\"<h2></h2>\").html('Pamätné dni na Slovensku').appendTo(\"#third h2\");
            $(\"#third\").append(\"<ul></ul>\");
            $.ajax({
                type: \"GET\",
                url: \"meniny.xml\",
                dataType: \"xml\",
                success: function (xml) {

                    $(xml).find('zaznam').each(function () {
                        var dat = $(this).find('den').text();
                        var name = $(this).find('SKdni').text();
                        var monthDay = dat.substr(2, 2)+ '.' + dat.substr(0, 2)+'.';
                        if(name != ''){
                            $(\"<li></li>\").html(monthDay + ' - ' + name).appendTo(\"#third ul\");
                        }
                        
                    });
                },
                error: function () {
                    alert(\"An error occurred while processing XML file.\");
                }
            });

    </script>";
        }
}

echo "<hr>";


echo "<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js\"></script>
<script>
console.log('in script to post');
$.ajax({
    url: \"meniny.xml\",
    data: \"<test>testData</test>\", 
    type: 'POST',
    contentType: \"text/xml\",
    dataType: \"text\",
    success : function (xml) {console.log('success');},
    error : function (xhr, ajaxOptions, thrownError){  
        console.log(xhr.status);          
        console.log(thrownError);
    } 
}); 
</script>

";


?>

</body>

